
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Xsl;

namespace XsltSample9 {

	public class Ext {

		public string ToUpper (string value) {
			return value.ToUpper ();
		}

	}

	public class Program {

		public static void Main (string [] commandLineArgs) {
			XslTransform xslt = new XslTransform ();
			XsltArgumentList args = new XsltArgumentList ();
			XmlDocument xdoc = new XmlDocument ();
			string outPath = Path.Combine (Application.StartupPath, "Customers.html"),
				xmlPath = Path.Combine (Application.StartupPath, "Customers.xml"),
				xslPath = Path.Combine (Application.StartupPath, "Customers_XHTML.xslt");

			args.AddExtensionObject ("urn:psc", new Ext ());
			xslt.Load (xslPath);
			xdoc.Load (xmlPath);

			using (StreamWriter stream = File.CreateText (outPath))
			using (XmlTextWriter writer = new XmlTextWriter (stream)) {
				writer.Formatting = Formatting.Indented;
				xslt.Transform (xdoc, args, writer, null);
			}
		}

	}

}
