
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Xsl;

namespace XsltSample8 {

	public class Program {

		public static void Main (string [] args) {
			XslTransform xslt = new XslTransform ();
			XmlDocument xdoc = new XmlDocument ();
			string outPath = Path.Combine (Application.StartupPath, "Customers.html"),
				xmlPath = Path.Combine (Application.StartupPath, "Customers.xml"),
				xslPath = Path.Combine (Application.StartupPath, "Customers_XHTML.xslt");

			xslt.Load (xslPath);
			xdoc.Load (xmlPath);

			using(StreamWriter stream=File.CreateText(outPath))
			using (XmlTextWriter writer = new XmlTextWriter (stream)) {
				writer.Formatting = Formatting.Indented;
				xslt.Transform (xdoc, null, writer, null);
			}
		}

	}

}
